import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.domain.Persona;


public class asdasd {

	private static ObjectContainer db = DataConnection.getInstance();
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Persona p = new Persona("admin", "admin", true);
		Persona p2 = new Persona("user", "user", false);
		db.store(p);
		db.store(p2);
	}

}
