package com.domain;

import java.util.ArrayList;

public class Catalog {
	
	private String nom;
	private ArrayList<Producte> productes;
	
	public Catalog(String nom, ArrayList<Producte> productes) {
		super();
		this.nom = nom;
		this.productes = productes;
	}
	
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public ArrayList<Producte> getProductes() {
		return productes;
	}
	public void setProductes(ArrayList<Producte> productes) {
		this.productes = productes;
	}

}
