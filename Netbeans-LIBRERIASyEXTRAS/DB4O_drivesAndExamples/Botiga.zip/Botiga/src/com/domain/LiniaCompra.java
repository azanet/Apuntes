package com.domain;

public class LiniaCompra {
	
	//client
	private String idcompra;
	private String idprod;
	private int num;
	
	public LiniaCompra(String idcompra, String idprod, int num) {
		super();
		this.idcompra = idcompra;
		this.idprod = idprod;
		this.num = num;
	}
	public String getIdcompra() {
		return idcompra;
	}
	public void setIdcompra(String idcompra) {
		this.idcompra = idcompra;
	}
	public String getIdprod() {
		return idprod;
	}
	public void setIdprod(String idprod) {
		this.idprod = idprod;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	

}
