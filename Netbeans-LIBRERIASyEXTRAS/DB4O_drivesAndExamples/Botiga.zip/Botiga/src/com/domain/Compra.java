package com.domain;

public class Compra {
	
	private String id;
	private String idClient;
	
	public Compra(String id, String idClient) {
		super();
		this.id = id;
		this.idClient = idClient;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIdClient() {
		return idClient;
	}
	public void setIdClient(String idClient) {
		this.idClient = idClient;
	}
	
	
}
