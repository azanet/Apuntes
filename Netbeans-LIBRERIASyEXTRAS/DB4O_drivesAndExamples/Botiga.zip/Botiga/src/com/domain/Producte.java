package com.domain;

public class Producte {
	
	private String id;
	private String nom;
	private int num;
	
	public Producte(String id, String nom, int num) {
		super();
		this.id = id;
		this.nom = nom;
		this.setNum(num);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}

}
