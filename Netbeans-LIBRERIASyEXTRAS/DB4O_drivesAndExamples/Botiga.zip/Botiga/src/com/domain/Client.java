package com.domain;

public class Client {
	
	private String DNI;
	private String nom;
	private String password;
	private String compteBancar;
	private String idClient;
	private String telefon;
	private boolean admin;
	
	public Client(String dNI, String nom, String password, String compteBancar,
			String idClient, String telefon, boolean admin) {
		super();
		DNI = dNI;
		this.nom = nom;
		this.password = password;
		this.compteBancar = compteBancar;
		this.idClient = idClient;
		this.telefon = telefon;
		this.setAdmin(admin);
	}
	public String getDNI() {
		return DNI;
	}
	public void setDNI(String dNI) {
		DNI = dNI;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCompteBancar() {
		return compteBancar;
	}
	public void setCompteBancar(String compteBancar) {
		this.compteBancar = compteBancar;
	}
	public String getIdClient() {
		return idClient;
	}
	public void setIdClient(String idClient) {
		this.idClient = idClient;
	}
	public String getTelefon() {
		return telefon;
	}
	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}
	public boolean isAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	
}
