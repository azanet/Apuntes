package com.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;
import com.domain.Client;

public class adminClients extends JFrame {

	private JPanel contentPane;
	private JTable tableClients;
	private ObjectContainer db = DataConnection.getInstance();

	/**
	 * Create the frame.
	 */
	public adminClients() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JButton btnElimina = new JButton("Elimina");
		btnElimina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableClients.getSelectedRow()!=-1){
					borrador();
					init();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Usuari");
				}
			}
		});
		
		JButton btnEdita = new JButton("Edita");
		btnEdita.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableClients.getSelectedRow()!=-1){
					Client t = (Client)tableClients.getModel().getValueAt(tableClients.getSelectedRow(), 3);
					creaClient cc = new creaClient(false, t);
					cc.setVisible(true);
					init();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Usuari");
				}
			}
		});
		
		JButton btnAfegeix = new JButton("Afegeix");
		btnAfegeix.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				creaClient cc = new creaClient(true, null);
				cc.setVisible(true);
				init();
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnAfegeix)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnEdita)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnElimina)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnCancel))
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 414, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancel)
						.addComponent(btnElimina)
						.addComponent(btnEdita)
						.addComponent(btnAfegeix))
					.addContainerGap())
		);
		
		tableClients = new JTable();
		tableClients.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id", "DNI", "Nom", "Objecte"
			}
		));
		scrollPane.setViewportView(tableClients);
		contentPane.setLayout(gl_contentPane);
		tableClients.removeColumn(tableClients.getColumn("Objecte"));
		init();
	}
	
	void init(){
		List<Client> lp = db.query(new Predicate<Client>() {
			public boolean match(Client o) {
				return true;
			}
		}, new Comparator<Client>() {
			public int compare(Client o1, Client o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		
		//List<Tema> lp = db.queryByExample(Tema.class);

		DefaultTableModel modelo = (DefaultTableModel)tableClients.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		for (Client usr : lp) {
			Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
			
			fila[0] = usr.getIdClient();
			fila[1] = usr.getDNI();
			fila[2] = usr.getNom();
			fila[3] = usr;
			
			modelo.addRow(fila);
				
		}
	}
	
	void borrador(){
		int resposta = JOptionPane.showConfirmDialog(null, "Segur que vols eliminar?", "Eliminar", JOptionPane.YES_NO_OPTION);
		if (resposta == JOptionPane.YES_OPTION) {
			Client user = (Client)tableClients.getModel().getValueAt(tableClients.getSelectedRow(), 3);
			db.delete(user);
		}
	}
}
