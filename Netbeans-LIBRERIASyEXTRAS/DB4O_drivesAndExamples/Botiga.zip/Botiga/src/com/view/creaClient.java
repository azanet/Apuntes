package com.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;
import com.domain.Client;

public class creaClient extends JDialog {

	private JPanel contentPane;
	private ObjectContainer db = DataConnection.getInstance();
	private boolean creacio;
	private Client client;
	private JTextField txtDNI;
	private JTextField txtNom;
	private JTextField txtPass;
	private JTextField txtCC;
	private JTextField txtTelf;
	private JCheckBox checkAdmin;

	/**
	 * Create the frame.
	 */
	public creaClient(final boolean creacio, Client client) {
		setModal(true);
		this.creacio=creacio;
		this.client=client;
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JButton btnOk = new JButton("Ok");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(creacio) crea();
				else update();
				dispose();
			}
		});
		
		JLabel lblDni = new JLabel("DNI:");
		
		JLabel lblNom = new JLabel("Nom:");
		
		JLabel lblPassword = new JLabel("Password:");
		
		JLabel lblCompteBancari = new JLabel("Compte Bancari:");
		
		JLabel lblTelefon = new JLabel("Telefon:");
		
		JLabel lblAdmin = new JLabel("Admin:");
		
		txtDNI = new JTextField();
		txtDNI.setColumns(10);
		
		txtNom = new JTextField();
		txtNom.setColumns(10);
		
		txtPass = new JTextField();
		txtPass.setColumns(10);
		
		txtCC = new JTextField();
		txtCC.setColumns(10);
		
		txtTelf = new JTextField();
		txtTelf.setColumns(10);
		
		checkAdmin = new JCheckBox("");
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnOk)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnCancel))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblDni)
							.addPreferredGap(ComponentPlacement.RELATED, 114, Short.MAX_VALUE)
							.addComponent(txtDNI, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNom)
							.addPreferredGap(ComponentPlacement.RELATED, 107, Short.MAX_VALUE)
							.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblPassword)
							.addPreferredGap(ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
							.addComponent(txtPass, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblCompteBancari)
							.addPreferredGap(ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
							.addComponent(txtCC, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblTelefon)
								.addComponent(lblAdmin))
							.addPreferredGap(ComponentPlacement.RELATED, 85, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(checkAdmin)
								.addComponent(txtTelf, GroupLayout.PREFERRED_SIZE, 271, GroupLayout.PREFERRED_SIZE))))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblDni)
						.addComponent(txtDNI, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom)
						.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPassword)
						.addComponent(txtPass, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCompteBancari)
						.addComponent(txtCC, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTelefon)
						.addComponent(txtTelf, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAdmin)
						.addComponent(checkAdmin))
					.addPreferredGap(ComponentPlacement.RELATED, 69, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancel)
						.addComponent(btnOk))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
		init();
	}
	
	void crea(){
		List<Client> lp = db.query(new Predicate<Client>() {
			public boolean match(Client o) {
				return true;
			}
		}, new Comparator<Client>() {
			public int compare(Client o1, Client o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		
		Client c = new Client(txtDNI.getText(), txtNom.getText(), txtPass.getText(), txtCC.getText(), Integer.toString(lp.size()), txtTelf.getText(), checkAdmin.isSelected());
		db.store(c);
		db.commit();
	}
	
	void update(){
		client.setAdmin(checkAdmin.isEnabled());
		client.setCompteBancar(txtCC.getText());
		client.setDNI(txtDNI.getText());
		client.setNom(txtNom.getText());
		client.setPassword(txtPass.getText());
		client.setTelefon(txtTelf.getText());
		db.commit();
	}
	
	void init(){
		if(!creacio){
			txtCC.setText(client.getCompteBancar());
			txtDNI.setText(client.getDNI());
			txtNom.setText(client.getNom());
			txtPass.setText(client.getPassword());
			txtTelf.setText(client.getTelefon());
			checkAdmin.setSelected(client.isAdmin());
		}
	}
}
