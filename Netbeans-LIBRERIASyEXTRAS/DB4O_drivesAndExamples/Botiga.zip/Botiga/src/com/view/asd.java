package com.view;

import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.domain.Client;

public class asd {
	
	private static ObjectContainer db = DataConnection.getInstance();
	
	public static void main(String[] args) {
		Client c = new Client("k", "k", "k", "k", "k", "k", true);
		db.store(c);
	}

}
