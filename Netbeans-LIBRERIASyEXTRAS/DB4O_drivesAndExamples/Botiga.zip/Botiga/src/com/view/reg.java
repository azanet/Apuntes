package com.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;
import com.domain.Client;

public class reg extends JFrame {

	private JPanel contentPane;
	private JTextField txtCC;
	private JTextField txtTelf;
	private JTextField txtNom;
	private JTextField txtDNI;
	private JPasswordField txtPass;
	private ObjectContainer db = DataConnection.getInstance();

	/**
	 * Create the frame.
	 */
	public reg() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JButton btnGuarda = new JButton("Guarda");
		btnGuarda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				registra();
			}
		});
		
		JLabel lblDni = new JLabel("DNI:");
		
		JLabel lblNom = new JLabel("Nom:");
		
		JLabel lblTelefon = new JLabel("Telefon:");
		
		JLabel lblComteBancari = new JLabel("Comte Bancari:");
		
		JLabel lblPassword = new JLabel("Password:");
		
		txtCC = new JTextField();
		txtCC.setColumns(10);
		
		txtTelf = new JTextField();
		txtTelf.setColumns(10);
		
		txtNom = new JTextField();
		txtNom.setColumns(10);
		
		txtDNI = new JTextField();
		txtDNI.setColumns(10);
		
		txtPass = new JPasswordField();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnGuarda)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnCancel))
						.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblComteBancari)
										.addComponent(lblPassword)
										.addComponent(lblTelefon)
										.addComponent(lblNom))
									.addPreferredGap(ComponentPlacement.UNRELATED))
								.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
									.addComponent(lblDni)
									.addGap(96)))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(txtTelf, GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
								.addComponent(txtCC, GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
								.addComponent(txtNom, GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
								.addComponent(txtDNI, GroupLayout.DEFAULT_SIZE, 289, Short.MAX_VALUE)
								.addComponent(txtPass, GroupLayout.PREFERRED_SIZE, 285, GroupLayout.PREFERRED_SIZE))))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblDni)
						.addComponent(txtDNI, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom)
						.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTelefon)
						.addComponent(txtTelf, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblComteBancari)
						.addComponent(txtCC, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblPassword)
						.addComponent(txtPass, GroupLayout.PREFERRED_SIZE, 17, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 83, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancel)
						.addComponent(btnGuarda))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}

	void registra(){
		List<Client> lp = db.query(new Predicate<Client>() {
			public boolean match(Client o) {
				return true;
			}
		}, new Comparator<Client>() {
			public int compare(Client o1, Client o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		
		Client c = new Client(txtDNI.getText(), txtNom.getText(), new String(txtPass.getPassword()), txtCC.getText(), Integer.toString(lp.size()), txtTelf.getText(), false);
		db.store(c);
		db.commit();
		dispose();
	}
	
}
