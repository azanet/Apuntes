package com.view;

import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;
import com.domain.Compra;
import com.domain.LiniaCompra;
import com.domain.Producte;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class detail extends JFrame {

	private JPanel contentPane;
	private JTable tableDetail;
	private Compra compra;
	private ObjectContainer db = DataConnection.getInstance();

	/**
	 * Create the frame.
	 */
	public detail(Compra compra) {
		this.compra=compra;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnOk, Alignment.TRAILING)
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 414, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnOk)
					.addContainerGap())
		);
		
		tableDetail = new JTable();
		tableDetail.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id compra", "Producte"
			}
		));
		scrollPane.setViewportView(tableDetail);
		contentPane.setLayout(gl_contentPane);
		init();
	}
	
	void init(){
		List<LiniaCompra> lp = db.query(new Predicate<LiniaCompra>() {
			public boolean match(LiniaCompra o) {
				return o.getIdcompra().equals(compra.getId());
			}
		});
		
		DefaultTableModel modelo = (DefaultTableModel)tableDetail.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		for (LiniaCompra usr : lp) {
			Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
			
			fila[0] = usr.getIdcompra();
			
			final String x = usr.getIdprod();
			
			List<Producte> prodl = db.query(new Predicate<Producte>() {
				public boolean match(Producte o) {
					return o.getId().equals(x);
				}
			});
			if(prodl.size()>0) fila[1] = prodl.get(0).getNom();
			else fila[1] = "fail";
			
			modelo.addRow(fila);
				
		}
	}

}
