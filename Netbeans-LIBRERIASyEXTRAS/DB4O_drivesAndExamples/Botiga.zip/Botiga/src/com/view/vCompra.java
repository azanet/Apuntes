package com.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;
import com.domain.Client;
import com.domain.Compra;
import com.domain.LiniaCompra;
import com.domain.Producte;

public class vCompra extends JFrame {

	private JPanel contentPane;
	private ObjectContainer db = DataConnection.getInstance();
	private Client c;
	private JTable tableProds;
	private JTable tableCarrito;
	private List<Producte> prodl;
	
	/**
	 * Create the frame.
	 */
	public vCompra(Client c) {
		this.c=c;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 367);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnCancel = new JButton("Cancel");
		
		JButton btnOk = new JButton("Ok");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableCarrito.getRowCount()>0){
					ferCompra();
					dispose();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Has de seleccionar algun producte");
				}
			}
		});
		
		JPanel panel = new JPanel();
		
		JLabel lblClient = new JLabel("Client:");
		
		JLabel label = new JLabel(c.getNom());
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblClient)
							.addGap(18)
							.addComponent(label))
						.addComponent(panel, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 414, Short.MAX_VALUE)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnOk)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnCancel)))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblClient)
						.addComponent(label))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 241, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancel)
						.addComponent(btnOk))
					.addContainerGap(123, Short.MAX_VALUE))
		);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JScrollPane scrollPane_1 = new JScrollPane();
		
		JButton button = new JButton(">");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				af();
			}
		});
		
		JButton button_1 = new JButton("<");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rem();
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE)
					.addGap(37)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addComponent(button)
						.addComponent(button_1))
					.addGap(18)
					.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 139, GroupLayout.PREFERRED_SIZE)
					.addGap(89))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 214, GroupLayout.PREFERRED_SIZE)
						.addComponent(scrollPane_1, 0, 0, Short.MAX_VALUE))
					.addGap(189))
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(87)
					.addComponent(button)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(button_1)
					.addContainerGap(108, Short.MAX_VALUE))
		);
		
		tableCarrito = new JTable();
		tableCarrito.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id", "Nom", "Objecte"
			}
		));
		scrollPane_1.setViewportView(tableCarrito);
		
		tableProds = new JTable();
		tableProds.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
					"Id", "Nom", "Objecte"
			}
		));
		scrollPane.setViewportView(tableProds);
		panel.setLayout(gl_panel);
		contentPane.setLayout(gl_contentPane);
		tableProds.removeColumn(tableProds.getColumn("Objecte"));
		tableCarrito.removeColumn(tableCarrito.getColumn("Objecte"));
		
		init();
	}
	
	void init(){
		prodl = db.query(new Predicate<Producte>() {
			public boolean match(Producte o) {
				return true;
			}
		}, new Comparator<Producte>() {
			public int compare(Producte o1, Producte o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		
		//List<Tema> lp = db.queryByExample(Tema.class);

		DefaultTableModel modelo = (DefaultTableModel)tableProds.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		for (Producte prod : prodl) {
			Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
			
			fila[0] = prod.getId();
			fila[1] = prod.getNom();
			fila[2] = prod;
			
			modelo.addRow(fila);
				
		}
	}
	
	void af(){
		Producte prod = (Producte)tableProds.getModel().getValueAt(tableProds.getSelectedRow(), 2);
		int numCols = tableProds.getModel().getColumnCount();
		Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla

		fila[0] = prod.getId();
		fila[1] = prod.getNom();
		fila[2] = prod;


		((DefaultTableModel) tableCarrito.getModel()).addRow(fila);
		((DefaultTableModel) tableProds.getModel()).removeRow(tableProds.getSelectedRow());
	}
	
	void rem(){
		Producte prod = (Producte)tableCarrito.getModel().getValueAt(tableCarrito.getSelectedRow(), 2);
		int numCols = tableCarrito.getModel().getColumnCount();
		Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla

		fila[0] = prod.getId();
		fila[1] = prod.getNom();
		fila[2] = prod;


		((DefaultTableModel) tableProds.getModel()).addRow(fila);
		((DefaultTableModel) tableCarrito.getModel()).removeRow(tableCarrito.getSelectedRow());
	}
	
	void ferCompra(){
		
		List<Compra> lc = db.query(new Predicate<Compra>() {
			public boolean match(Compra o) {
				return true;
			}
		});
		
		Compra cm = new Compra(Integer.toString(lc.size()), c.getIdClient());
		db.store(cm);
		db.commit();
		
		for (int i = 0; i < tableCarrito.getRowCount(); i++) {
			Producte prod = (Producte)tableCarrito.getModel().getValueAt(i, 2);
			LiniaCompra linc = new LiniaCompra(cm.getId(), prod.getId(), 1);
			db.store(linc);
			db.commit();
		}
	}
}
