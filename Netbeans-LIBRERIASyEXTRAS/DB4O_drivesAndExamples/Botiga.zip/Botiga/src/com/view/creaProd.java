package com.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;
import com.domain.Producte;

public class creaProd extends JDialog {

	private JPanel contentPane;
	private ObjectContainer db = DataConnection.getInstance();
	private boolean creacio;
	private Producte producte;
	private JTextField txtNom;

	/**
	 * Create the frame.
	 */
	public creaProd(final boolean creacio, Producte producte) {
		setEnabled(true);
		this.creacio=creacio;
		this.producte=producte;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 452, 146);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnCance = new JButton("Cancel");
		btnCance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(creacio) guarda();
				else update();
				dispose();
			}
		});
		
		JLabel lblNom = new JLabel("Nom:");
		
		txtNom = new JTextField();
		txtNom.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnOk)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnCance))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNom)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(txtNom, GroupLayout.DEFAULT_SIZE, 360, Short.MAX_VALUE)))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom)
						.addComponent(txtNom, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 199, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCance)
						.addComponent(btnOk))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
		init();
	}
	
	void init(){
		if(!creacio){
			txtNom.setText(producte.getNom());
		}
	}
	
	void guarda(){
		List<Producte> lp = db.query(new Predicate<Producte>() {
			public boolean match(Producte o) {
				return true;
			}
		}, new Comparator<Producte>() {
			public int compare(Producte o1, Producte o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		
		Producte p = new Producte(Integer.toString(lp.size()), txtNom.getText(), 0);
		db.store(p);
		db.commit();
	}
	
	void update(){
		producte.setNom(txtNom.getText());
		db.commit();
	}

}
