package com.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;
import com.domain.Producte;

public class adminProds extends JFrame {

	private JPanel contentPane;
	private JTable tableProds;
	private ObjectContainer db = DataConnection.getInstance();

	/**
	 * Create the frame.
	 */
	public adminProds() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JButton btnElimina = new JButton("Elimina");
		btnElimina.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableProds.getSelectedRow()!=-1){
					borrador();
					init();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Usuari");
				}
			}
		});
		
		JButton btnEdita = new JButton("Edita");
		btnEdita.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tableProds.getSelectedRow()!=-1){
					Producte t = (Producte)tableProds.getModel().getValueAt(tableProds.getSelectedRow(), 3);
					creaProd cc = new creaProd(false, t);
					cc.setVisible(true);
					init();
				}else{
					JOptionPane.showMessageDialog(contentPane,"Selecciona algun Usuari");
				}
			}
		});
		
		JButton btnCrea = new JButton("Crea");
		btnCrea.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				creaProd cp = new creaProd(true, null);
				cp.setVisible(true);
				init();
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnCrea)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnEdita)
							.addGap(12)
							.addComponent(btnElimina)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnCancel))
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 414, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancel)
						.addComponent(btnElimina)
						.addComponent(btnEdita)
						.addComponent(btnCrea))
					.addContainerGap())
		);
		
		tableProds = new JTable();
		tableProds.setModel(new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"Id", "Nom", "Objecte"
				}
			));
		scrollPane.setViewportView(tableProds);
		contentPane.setLayout(gl_contentPane);
		tableProds.removeColumn(tableProds.getColumn("Objecte"));
		init();
	}
	
	void init(){
		List<Producte> lp = db.query(new Predicate<Producte>() {
			public boolean match(Producte o) {
				return true;
			}
		}, new Comparator<Producte>() {
			public int compare(Producte o1, Producte o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		
		//List<Tema> lp = db.queryByExample(Tema.class);

		DefaultTableModel modelo = (DefaultTableModel)tableProds.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		for (Producte usr : lp) {
			Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
			
			fila[0] = usr.getId();
			fila[1] = usr.getNom();
			fila[2] = usr;
			
			modelo.addRow(fila);
				
		}
	}
	
	void borrador(){
		int resposta = JOptionPane.showConfirmDialog(null, "Segur que vols eliminar?", "Eliminar", JOptionPane.YES_NO_OPTION);
		if (resposta == JOptionPane.YES_OPTION) {
			Producte user = (Producte)tableProds.getModel().getValueAt(tableProds.getSelectedRow(), 2);
			db.delete(user);
		}
	}
}
