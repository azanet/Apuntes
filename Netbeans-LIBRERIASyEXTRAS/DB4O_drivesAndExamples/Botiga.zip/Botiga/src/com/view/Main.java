package com.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Comparator;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;
import com.domain.Client;

public class Main extends JFrame {

	private JPanel contentPane;
	private JTextField txtDNI;
	private JPasswordField txtPass;
	private ObjectContainer db = DataConnection.getInstance();
	private Client c;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnConsultarCataleg = new JButton("Consultar Cataleg");
		btnConsultarCataleg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mostraCataleg m = new mostraCataleg();
				m.setVisible(true);
			}
		});
		
		JButton btnNewButton = new JButton("Logejarse");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(login()){
					//
					if(c.isAdmin()){
						//pantalla admin
						pAdmin ad = new pAdmin();
						ad.setVisible(true);
					}else{
						//pantalla compra
						vCompra c2 = new vCompra(c);
						c2.setVisible(true);
					}
				}
			}
		});
		
		JLabel lblNom = new JLabel("DNI:");
		
		txtDNI = new JTextField();
		txtDNI.setText("");
		txtDNI.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password:");
		
		txtPass = new JPasswordField();
		
		JButton btnRegistrare = new JButton("Registrarse");
		btnRegistrare.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reg r = new reg();
				r.setVisible(true);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(12)
							.addComponent(btnNewButton)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnRegistrare)
							.addPreferredGap(ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
							.addComponent(btnConsultarCataleg))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblPassword)
								.addComponent(lblNom))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(txtDNI, GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE)
								.addComponent(txtPass, GroupLayout.DEFAULT_SIZE, 327, Short.MAX_VALUE))))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNom)
						.addComponent(txtDNI, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblPassword)
						.addComponent(txtPass, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 165, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnConsultarCataleg)
						.addComponent(btnRegistrare)
						.addComponent(btnNewButton))
					.addContainerGap())
		);
		contentPane.setLayout(gl_contentPane);
	}
	
	boolean login(){
		boolean ret=false;
		
		List<Client> lp = db.query(new Predicate<Client>() {
			public boolean match(Client o) {
				return (o.getDNI().equals(txtDNI.getText()) && o.getPassword().equals(new String(txtPass.getPassword())));
			}
		}, new Comparator<Client>() {
			public int compare(Client o1, Client o2) {
				return o1.getNom().compareTo(o2.getNom());
			}
		});
		
		if(lp.size()>0){
			c = lp.get(0);
			ret=true;
		}
		
		return ret;
	}
}
