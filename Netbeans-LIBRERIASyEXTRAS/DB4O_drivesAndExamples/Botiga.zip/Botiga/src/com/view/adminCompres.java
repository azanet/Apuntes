package com.view;

import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.data.DataConnection;
import com.db4o.ObjectContainer;
import com.db4o.query.Predicate;
import com.domain.Compra;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class adminCompres extends JFrame {

	private JPanel contentPane;
	private JTable tableCompra;
	private ObjectContainer db = DataConnection.getInstance();
	
	/**
	 * Create the frame.
	 */
	public adminCompres() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnDetail = new JButton("Detail");
		btnDetail.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Compra t = (Compra)tableCompra.getModel().getValueAt(tableCompra.getSelectedRow(), 2);
				detail d = new detail(t);
				d.setVisible(true);
			}
		});
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addComponent(btnDetail)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnOk))
						.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 414, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 201, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnOk)
						.addComponent(btnDetail))
					.addContainerGap())
		);
		
		tableCompra = new JTable();
		tableCompra.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Id", "IdClient", "Objecte"
			}
		));
		scrollPane.setViewportView(tableCompra);
		contentPane.setLayout(gl_contentPane);
		tableCompra.removeColumn(tableCompra.getColumn("Objecte"));
		init();
	}
	
	void init(){
		List<Compra> lp = db.query(new Predicate<Compra>() {
			public boolean match(Compra o) {
				return true;
			}
		});
		
		//List<Tema> lp = db.queryByExample(Tema.class);

		DefaultTableModel modelo = (DefaultTableModel)tableCompra.getModel();
		while (modelo.getRowCount() > 0) modelo.removeRow(0);
		int numCols = modelo.getColumnCount();
		for (Compra usr : lp) {
			Object [] fila = new Object[numCols]; // Hay tres columnas en la tabla
			
			fila[0] = usr.getId();
			fila[1] = usr.getIdClient();
			fila[2] = usr;
			
			modelo.addRow(fila);
				
		}
	}

}
