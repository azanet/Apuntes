package mdlaf.utils.icons;

import jiconfont.IconCode;

/**
 * TAG interface
 * @author https://github.com/vincenzopalazzo
 */
public interface IMaterialIconCode extends IconCode { }
