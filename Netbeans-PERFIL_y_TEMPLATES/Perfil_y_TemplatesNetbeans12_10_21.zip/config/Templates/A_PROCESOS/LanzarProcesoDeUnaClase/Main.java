/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leerclientes;

/**
 *
 * @author davidf
 */
public class Main {

    private static ProcessLauncher pl = new ProcessLauncher();

    public static void main(String[] args) {
        // TODO code application logic here

        if (args.length == 1) {

            try {
                //Ejecutando Lanzador de procesos
                pl.launchReadClients(Long.parseLong(args[0]));

            } catch (NumberFormatException nfe) {
                System.out.println("ERROR: Solo se acepta UN parámetro.\nDebe ser un Número ENTERO\n"
                        + "És el intervalo en SEGUNDOS de cada cuanto se leera el archivo 'Clientes.txt' ");
            }

        } else {
            System.out.println("ERROR: Sólo se Acepta UN parámetro (Número Entero).");
        }

        pl = null;

        System.exit(0);
    }//Fin del Main

}
