/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registrares;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;

/**
 *
 * @author davidf
 * Este proyecto al compilar será un .JAR que posteriormente lanzaremos
 * como proceso desde otro proyecto JAVA.
 * 
 * Se utiliza "RandomAccessFile" para poder bloquear el CHANNEL del Archivo con el que trabaja
 */
public class RegistrarES {

    private static RegistrarES registrar = new RegistrarES();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        if (args.length == 1) {
            System.out.println(WriteInFile(args[0]));

        } else {
            System.out.println("ERROR\nSolo se admite 1 argumento (+1 o -1)");
        }

        registrar = null;
        System.exit(0);

    }//Fin del Main

    
    
    
    //Método para Insertar la entrada Recibida (se asegurará de que sea la esperada[+1 o -1])
    private static String WriteInFile(String number) {
        //Datos a RETORNAR
        String data = number;

        //Componemos el nombre del archivo a buscar,
        final String FILENAME = "Clientes.txt";

        /*Haciendo para Obtener la Ruta (en cualquier SO) 
        / de donde tenemos que escribir el Archivo .txt*/
        final String nameJAR = RegistrarES.class.getSimpleName() + ".jar";
        final String jarPath = (new File(RegistrarES.class.getProtectionDomain().getCodeSource().getLocation().getPath())).toString().replaceAll(nameJAR, "");
        //Ruta donde se debe encontrar el Archivo a LEER
        final String filePath = jarPath + FILENAME;
//        System.out.println(jarPath);

        //Instanciando objeto FileLock para realizar bloqueo del archivo
        FileLock bloqueo;

        try {
            //comprobamos que existe el ARCHIVO a consultar, y si está lo leemos
            File fichero = new File(filePath);

            if (fichero.exists()) {
                //Accedemos al Archivo como LECTURA-escritura
                RandomAccessFile writer = new RandomAccessFile(fichero, "rw");

                //Asegurándonos de que entra solo un dato ESPERADO
                if (data.matches("^(\\+1|\\-1){1}$")) {
                    //  System.out.println("Proceso Escritor, entrando en Sección Crítica");   
           
                //Bloqueamos el canal del archivo
                    bloqueo = writer.getChannel().lock();

                    //Colocamos puntero en posición FINAL del archivo para proceder a escribir
                    writer.seek(writer.length());

                    //Escribiendo +1 o -1 en el ARCHIVO
                    writer.writeBytes(data + "\n");
                    data = "OK: " + data;
                    bloqueo.release();

                } else {

                    data = "ERROR\nSolo se admite (+1 o -1)";
                }

                //Quitamos bloqueo y cerramos el lector                
                //             System.out.println("Proceso Escritor, SALIENDO de Sección Crítica");                
                writer.close();

            } else {

                data = "No existe Fichero: " + FILENAME + ". Se necesita crear uno.\n";

            }

        } catch (IOException ioe) {
            data = "EXCEPTION Error al escribir el fichero.\n\n";
        } catch (Exception e) {
            data = "EXCEPTION Error de escritura\n\n";

        }//Fin del Try-Catch

        bloqueo = null;
        return data;

    }

}
