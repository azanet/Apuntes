package Utils;

import java.io.Serializable;

/**
 *
 * @author David Freyre Muñoz <https://github.com/azanet>
 */
public class OBJFileRequest implements Serializable{
           /** path completo del fichero que se pide */
     public String nombreFichero;

}
