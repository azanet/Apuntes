/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kakaaa;

//

import java.io.Serializable;

//
////////////////////////////////////////////////////////////
//ADJUNTANDO CLASE "CLIENTE" con la que FUNCIONA el EJEMPLO
///////////////////////////////////////////////////////////
//
//
//La CLASE, para poder ser almacenada en un fichero Serializable, debe IMPLEMENTAR la interface "Serializable".
    class Clientes implements Serializable {

        //DICEN, que esta linea puede evitar algunos problemas al trabajar con los ficheros serializados
        //y parece que provee de una especie de ID al objeto y no se si realmente la utilizará para algo de forma interna.
        //Ya que el ejercico está hecho con intención de servir de GUIA en un futuro, dejaré esta línea tal cual aunque
        //realmente.. el codigo funciona perfectamente sin ella, pero prefiero tenerla aqúi por si algún dia llegara hacer falta.
        private static final long serialVersionUID = -1L;

        //Declarando variables
        private String nif;
        private String nombre;
        private String telefono;
        private String direccion;
        private double deuda;

        //Constructor parametrizado
        public Clientes(String nif, String nombre, String telefono, String direccion, double deuda) {
            this.nif = nif;
            this.nombre = nombre;
            this.telefono = telefono;
            this.direccion = direccion;
            this.deuda = deuda;
        }//Fin del constructor parametrizado

        //Constructor vacío
        public Clientes() {
            
        }//Fin del constructor vacío

        //Getters
        public String getNif() {
            return nif;
        }
        
        public String getNombre() {
            return nombre;
        }
        
        public String getTelefono() {
            return telefono;
        }
        
        public String getDireccion() {
            return direccion;
        }
        
        public double getDeuda() {
            return deuda;
        }
        
    }//Fin de la clase CLIENTE