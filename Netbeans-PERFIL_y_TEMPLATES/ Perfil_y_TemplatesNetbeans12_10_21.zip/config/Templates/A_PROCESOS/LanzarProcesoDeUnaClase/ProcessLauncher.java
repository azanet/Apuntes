/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leerclientes;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

/**
 *
 * @author davidf
 */
public class ProcessLauncher {

    //Constructor vacio
    public ProcessLauncher() {
    }

    //Metodo público que llama a metodo privado (encapsulando el método)
    public void launchReadClients(long seconds) {
        launchLectorDePacientesP(seconds);
    }

    //Estableciendo el método que va a funcionar como Privado para evitar que se pueda acceder a este
    private void launchLectorDePacientesP(long seconds) {

        final long miliseconds = (seconds * 1000);

        //Var que almacena los DATOS a IMPRIMIR
        String data = "";

        //Deteerminando PAQUETE y CLASE del .JAR a EJECUTAR por el PROCESO
        String clase = "leerclientes.LeerClientes";
        //Determinando Ruta del .JAR
        final String jarPath = new File(LeerClientes.class.getProtectionDomain().getCodeSource().getLocation().getFile()).toString();
//        System.out.println(jarPath);

        //Array de Comando que ejecutará el ProcessBuilder
        final String[] cmd;

        /* Determinando en qué sistema operativo está ejecutandose, para adaptar el comando. 
        /*
        /* El COMANDO (cmd) a lanzar, 
        /* EJECUTARÁ un Proceso de UNA CLASE contenida en el .JAR (la CLASE a EJECUTAR deberá contar con un método MAIN)
        /*
        /* El "CMD" de compone de: 
        /* "java -cp" (flag para indicar el classPath) + 
        /*  la ruta completa del .JAR al que pertenece la clase + 
        /*  nombre del Paquete y Clase a EJECUTAR + argumentos a pasarle
         */
        if (System.getProperty("os.name").toUpperCase().contains("LINUX")) {
            //For LINUX
            cmd = new String[]{"/bin/bash", "-c", "java -cp " + jarPath + " " + clase};
        } else {
            //For Others 
            cmd = new String[]{"java","-cp",jarPath,clase};
        }

        try {

            while (1 == 1) {

                try {

                    //LANZAMOS PROCESO y Generamos un objeto Process, para poder trabajar con los estados, salidas, etc. de este proceso
                    Process process = new ProcessBuilder(cmd).redirectErrorStream(true).start();

                    // Obtener la salida del proceso
                    BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));

                    //Almacenando en DATA la información retornada por el PROCESO
                    data = br.lines().collect(Collectors.joining("\n"));
                    //Cerrando BuffRead
                    br.close();

                    //Imprimiendo salida del Proceso
                    if (data.contains("ERROR")){
                        System.out.println(data);
                        break;
                        
                    }
                    
                    System.out.println(data);

                    Thread.sleep(miliseconds);

                } catch (InterruptedException ex) {
                    System.out.println("ERROR " + ex.getMessage());
                    //Forzamos salida del While
                    //           break;
                } 

            }//FIN de WHILE true

        } catch (IOException ioe) {
            System.out.println("EXCEPTION Error al lanzar el Proceso 'LeerClientes'\n");
        }

    }

}
