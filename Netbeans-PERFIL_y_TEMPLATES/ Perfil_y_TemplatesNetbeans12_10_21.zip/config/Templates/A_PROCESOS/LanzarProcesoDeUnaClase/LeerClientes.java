/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leerclientes;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author davidf
 */
public class LeerClientes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print(readFileClients());

    }//Fin del Main

    private static String readFileClients() {
   
        //Dando formato a la Fecha-Hora
        final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        //Datos a RETORNAR
        String data = "";
        //Contador para controlar Entradas y Salidas
        long count = 0;
        //Componemos el nombre del archivo a buscar,
        final String FILENAME = "Clientes.txt";

        /*Haciendo para Obtener la Ruta (en cualquier SO) de donde tenemos que leer el Archivo .txt*/
        //Obtenemos nombre delJAR
        final String nameJAR = LeerClientes.class.getSimpleName() + ".jar"; 
        //Obtenemos ruta delJAR, eliminanos nombre del JAR y cambianos nombre del directorio, por donde se encuentra nuestro archivo
        final String jarPath = (new File(LeerClientes.class.getProtectionDomain().getCodeSource().getLocation().getPath())).toString().replaceAll(nameJAR, "").replaceAll("LeerClientes", "RegistrarES");
        //Ruta donde se debe encontrar el Archivo a LEER
        final String filePath = jarPath + FILENAME;

        //comprobamos que existe el ARCHIVO a consultar, y si está lo leemos
        try {
            File fichero = new File(filePath);

            if (fichero.exists()) {
                //Accedemos al Archivo como LECTURA-escritura 
                RandomAccessFile reader = new RandomAccessFile(fichero, "rw");
                //Bloqueamos el canal del archivo
                FileLock bloqueo = reader.getChannel().lock();

                //Colocamos puntero en posición Inicial
                reader.seek(0);

                if (fichero.length() == 0) {

                    data = "Ningún registro de Entradas\n";

                } else {
                    //Comrpoobamos que realmente exista la siguiente linea antes de intentar mostrarla y terminar en error

                    String lineRead = reader.readLine();

                    while (lineRead != null) {

                        //Comrpbando si es +1 o -1 para sumas o restar contador
                        if (lineRead.equalsIgnoreCase("+1")) {
                            count++;
                        } else if (lineRead.equalsIgnoreCase("-1")) {
                            count--;
                        }

                        lineRead = reader.readLine();
                    }//Fin del While

                    data = dtf.format(LocalDateTime.now()) + " Hay " + count + " clientes.\n";

                }

                //Quitamos bloqueo y cerramos el lector                
                bloqueo.release();
                bloqueo = null;

                reader.close();

            } else {
                data = "ERROR No existe Fichero 'Clientes.txt'\n";
                
            }

        } catch (IOException ioe) {
            data = "ERROR al leer el fichero.\n\n";
        } catch (Exception e) {
            data = "ERROR de lectura\n\n";
        }//Fin del Try-Catch

        return data;

    }

}//Fin de la Clase Principal
