/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lanzador;

import java.io.IOException;

/**
 *
 * @author davidf
 */
public class Main {

    private static ProcessLauncher pl = new ProcessLauncher();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        if (args.length == 1) {

            try {

                //Reiniciando el fichero Clientes.txt
                System.out.println(pl.initFile());

                //Lanzando Generador de entradas 
                generateRandomIO(Long.parseLong(args[0]));

            } catch (IOException ioe) {
                System.out.println("ERROR al Reiniciar archivo 'Clientes.txt\nNo se ejecutará NADA'");
                pl = null;
            } catch (NumberFormatException nfe) {
                System.out.println("ERROR\nSolo se admite 1  argumento y debe ser un NÚMERO.");
                pl = null;
            }

        } else {
            System.out.println("ERROR\nSolo se admite 1  argumento y debe ser un NÚMERO.");
        }

        pl = null;

        System.exit(0);

    }//Fin del MAIN

    private static void generateRandomIO(long quantity) {
        //Contadores de entradas y salidas
        long entry = 0;
        long exit = 0;

        for (int i = 0; i < quantity; i++) {

            //Adquiriendo un Numero Random para determinar entrada(Random) a ingresar           
            String numRandomStr = Long.toString(System.currentTimeMillis());
            int numRandom = Character.getNumericValue(numRandomStr.charAt(numRandomStr.length() - 1));

            //Este metodo es una puta mierda autentica, salen par e impar casi siempre al 50%
//          long numRandom = (Math.round(Math.random()));
//Si es PAR o mayor que 5 almacenará TRUE, si es IMPAR almacenará FALSE
            boolean input = (numRandom > 5 || (numRandom % 2) == 0);

            if (input) {
                //Insertando +1 
                System.out.println(pl.launchRegistrarIO("+1"));
                entry++;

            } else {
                //Comprobando si se puede insertar -1
                if (entry > exit) {
                    //Insertando -1
                    System.out.println(pl.launchRegistrarIO("-1"));
                    exit++;

                } else {
                    //Insertando +1 FORZADO 
                    System.out.println(pl.launchRegistrarIO("+1"));
                    entry++;

                }

            }//Fin del IF-else- INPUT

        }//Fin del FOR
        System.out.println("Aforo Actual Simulado: " + (entry - exit));
    }//Fin de GenerateRandomIO

}//Fin de clase Principal
