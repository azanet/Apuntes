/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lanzador;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

/**
 *
 * @author davidf
 */
public class ProcessLauncher {

    //Determinando Ruta del RegistrarES.JAR a LANZAR por el Lanzador(que es este)
    private final String jarPath = new File(ProcessLauncher.class.getProtectionDomain().getCodeSource().getLocation().getFile()).toString().replaceAll("(Lanzador)", "RegistrarES");
    //Ruta del archivo TXT
    private final String filePath = jarPath.replaceAll("(RegistrarES.jar)", "Clientes.txt");

    //Constructor vacio
    public ProcessLauncher() {
    }

    //Metodo para Reiniciar el Archivo de Clientes.TXT
    public String initFile() throws IOException {
        return initFileP();
    }

    private String initFileP() throws IOException {
//        System.out.println(filePath); 
        File clientes = new File(filePath);
        clientes.delete();
        System.gc();
        clientes.createNewFile();
        return "Archivo 'Clientes.txt' Reiniciado";

    }

    //Metodo que Lanzará un proceso del JAR que actualizará el registro de Clientes
    public String launchRegistrarIO(String date) {
        return launchRegistrarIOP(date);
    }

    //Estableciendo el método que va a funcionar como Privado para evitar que se pueda acceder a este
    private String launchRegistrarIOP(String date) {

//        System.out.println(jarPath);
        //Mensaje con los DATOS a Retornar
        String data = "";

        //Array de Comando que ejecutará el ProcessBuilder
        final String[] cmd;

        /* Determinando en qué sistema operativo está ejecutandose, para adaptar el comando. 
        /*
        /* El COMANDO (cmd) a lanzar, 
        /* EJECUTARÁ un Proceso de UNA CLASE contenida en el .JAR (la CLASE a EJECUTAR deberá contar con un método MAIN)
        /*
        /* El "CMD" de compone de: 
        /* "java -jar" (flag para indicar el jar) + 
        /*  la ruta completa del .JAR  + 
        /*  nombre del .JAR + argumentos a pasarle
         */
        if (System.getProperty("os.name").toUpperCase().contains("LINUX")) {
            //For LINUX
            cmd = new String[]{"/bin/bash", "-c", "java -jar " + jarPath + " " + date};
        } else {
            //For Others =D
            cmd = new String[]{"java","-jar",jarPath,date};
        }

        try {
//       System.out.println("INFO > antes del START Proceso");

            //LANZAMOS PROCESO y Generamos un objeto Process, para poder trabajar con los estados, salidas, etc. de este proceso
            Process process = new ProcessBuilder(cmd).redirectErrorStream(true).start();

            // Obtener la salida del proceso
            BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));

            //Almacenando en DATA la información retornada por el PROCESO
            data = br.lines().collect(Collectors.joining("\n"));
            //Cerrando BuffRead
            br.close();

//        System.out.println("INFO > después del START");
        } catch (IOException ioe) {
            data = ("EXCEPTION Error al lanzar el Proceso\n");
        }
        //Retornando DATA 
        return data;
    }

}
