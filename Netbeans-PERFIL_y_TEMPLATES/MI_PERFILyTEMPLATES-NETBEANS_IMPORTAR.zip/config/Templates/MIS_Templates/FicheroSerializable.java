/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */        //Interface de la clase "CLIENTE"
 
package kakaaa;
     
        //FICHERO SERIALIZABLE-- EJEMPLO COMPLETO CON CLASE INCLUIDA AL FINAL

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author davidf
 */
public class FicheroSerializable {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
   
         /** @author David Freyre Muñoz Fecha: 24/04/2020
         *
         * Descripcion: Fichero SERIALIZADO
         *
         * Crear clase cliente y operar con ella, crear OBJETOS cliente y
         * agregarlos al ARCHIVO. crear, listar, buscar, eliminar.
         */

            String nif = null;
            String nombre = null;
            String telefono = null;
            String direccion = null;
            double deuda = 0;
            boolean error = true;
            int opcion;
            String input = "";
            Scanner teclado = new Scanner(System.in);
            
            do {
                try {
                    error = true;
                    System.out.println();
                    System.out.println("1.- AÑADIR CLIENTE");
                    System.out.println("2.- LISTAR CLIENTES");
                    System.out.println("3.- BUSCAR CLIENTES");
                    System.out.println("4.- BORRAR CLIENTE");
                    System.out.println("5.- BORRAR FICHERO");
                    System.out.println("6.- SALIR DE LA APLICACION");
                    System.out.println();
                    System.out.print("SELECCIONE UNA OPCION DEL MENU: ");
                    opcion = teclado.nextInt();
                    System.out.println();
                } catch (InputMismatchException ime) {
                    System.out.println("El tipo de dato introducido no es correcto");
                    error = true;
                    continue;
                } catch (Exception e) {
                    System.out.println("Error de teclado");
                    error = true;
                    continue;
                } finally {
                    teclado.nextLine();
                }

                //Comienza El Switch que entrará a la opción elegida
                switch (opcion) {

                    //Ejecutará Agregar cliente
                    case 1: {
                        System.out.print("Agregando cliente:\n\n");

                        //SOLICITAMOS TODOS LOS DATOS para poder crear el OBJETO CLIENTE y luego almacenarlo en el archivo.
                        System.out.print("Introduzca DNI:\n->");
                        nif = teclado.nextLine();
                        
                        System.out.print("Introduzca Nombre:\n->");
                        nombre = teclado.nextLine();
                        
                        System.out.print("Introduzca Telefono:\n->");
                        telefono = teclado.nextLine();
                        
                        System.out.print("Introduzca Dirección:\n->");
                        direccion = teclado.nextLine();
                        
                        do {
                            System.out.print("Introduzca Deuda:\n->");
                            input = teclado.nextLine();
                            try {
                                deuda = Float.parseFloat(input);
                                error = false;
                            } catch (Exception e) {
                                System.out.println("\n++ERROR, Introduzca un NÚMERO (decimal o entero)");
                                error = true;
                            }//Fin de la excepcion
                        } while (error);
                        error = true;

                        //Creando cliente con los datos recibidos por el usuario
                        Clientes cliente = new Clientes(nif, nombre, telefono, direccion, deuda);

                        //Comprobamos que el DNI del cliente no existe en la lista, y si no existe lo agregamos
                        //Utilizaremos el retorno de la siguiente función, (el return fue creado para este propósito)
                        //En caso de existir se imprimrá en la pantalla, aprovechando al metodo buscarCliente que ya lo hace.
                        if (!buscarClientes(cliente.getNif())) {

                            //Llamando al metodo "AñadirCliente" pasandole como parámetro el objeto creado
                            anadirCliente(cliente);
                            System.out.println("\nEl CLIENTE se añadió Satisfactoriamente.\n\n");
                            
                        } else {
                            
                            System.out.println("\nEl CLIENTE NO se añadió a la lista, YA EXISTE.\n\n");
                        }//Fin del If-else    

                        break;
                    }//Fin del case1

                    //Ejecutará Listar clientes
                    case 2: {

                        //Llamando al metodo "listarClientes" 
                        listarClientes();
                        error = true;
                        break;
                    }//Fin del case2

                    //Ejecutará Buscar cliente y mostrar.
                    case 3: {
                        do {
                            try {
                                error = true;
                                String buscarDni;
                                System.out.print("Introduzca el DNI del cliente a buscar: ");
                                buscarDni = teclado.nextLine();

                                //Llamando al metodo "buscarClientes", pasandole como parametro el DNI introducido por el usuario
                                buscarClientes(buscarDni);
                                error = false;
                            } catch (Exception e) {
                                System.out.println(e.getMessage());
                            }
                        } while (error);
                        error = true;
                        break;
                    }//Fin del case3

                    //Ejecutará ELIMINAR cliente.
                    case 4: {
                        do {
                            try {
                                error = true;
                                String borrarNif;
                                System.out.print("Introduzca el DNI del cliente a Borrar: ");
                                borrarNif = teclado.nextLine();

                                //Llamando al metodo "borrarClientes", pasandole como parametro el DNI introducido por el usuario
                                borrarCliente(borrarNif);
                                error = false;
                            } catch (Exception e) {
                                //System.out.println(e.getMessage());
                                error = false;
                            }//Fin del try-Catch
                        } while (error);
                        error = true;
                        break;
                    }//Fin del case4

                    //Ejecutará BORRAR FICHERO
                    case 5: {
                        System.out.print("¿Seguro que desea borrar el fichero? (s para borrar u otra tecla para anular): ");
                        String borrado = teclado.nextLine();
                        if (borrado.equals("s")) {

                            //Llamando al metodo "borrarFichero"
                            borrarFichero();
                        } else {
                            System.out.println("La acción ha sido cancelada");
                        }
                        break;
                    }//Fin del case5

                    //Ejecutará Salir del programa.
                    case 6: {
                        //esta variable hará que pare bucle para poder salir del programa
                        error = false;
                        break;
                    }//Fin del case6

                }//Fin del SWITCH

            } while (error);
            //Fin del While

            System.out.println("Fin del programa");
            
        }//Fin del bloque MAIN

//=======================================================================================================   
        public static void anadirCliente(Clientes cliente) {
            try {
                
                File fichero = new File("cli.dat");
                if (fichero.exists() == false) {
                    fichero.createNewFile();
                }
                FileOutputStream flujo = new FileOutputStream(fichero, true);

                //Comprobaremos si el fichero tiene algo escrito (para determinar si tiene ya algun Registro).
                //Depende de si tiene o no, deberemos escribir el objeto utilizando la CLASE "ObjectOutputStream" normal,
                //o si tiene registros, utilizaremos la CLASE sobreescrita "MiObjectOutputStream"
                //que esta última "extirpará" la cabecera con la que escribe java los objetos serializables en los archivos.
                if (fichero.length() == 0) {
                    //Si NO tiene registros, creamos "objeto" escritor con la Clase NORMAL. para escribir la cabecera del objeto. 
                    ObjectOutputStream escritor = new ObjectOutputStream(flujo);
                    escritor.writeObject(cliente);
                    //Cerramos flujo y escritor
                    flujo.close();
                    escritor.close();

                    //Si SI tiene Registros, UTIlizaremos creamos "objeto" escritor con la clase "SOBREESCRITA" para escribir lo9s objetos sin cabeceras.               
                } else {
                    ObjectOutputStream escritor = new MiObjectOutputStream(flujo);
                    escritor.writeObject(cliente);
                    //Cerramos flujo y escritor 
                    flujo.close();
                    escritor.close();
                }

                //En este metodo no controlaremos el EOF, porque solo vamos a escribir y los va a ir añadiendo directamente al final 
            } catch (IOException ioe) {
                System.out.println("Error de fichero");
            } catch (Exception e) {
                System.out.println(e.initCause(e));
            }
        }

//=======================================================================================================  
        public static void listarClientes() {
            try {

                //Cargamos fichero y declaramos objetos para "leer"
                File fichero = new File("cli.dat");
                FileInputStream flujo = new FileInputStream(fichero);
                ObjectInputStream lector = new ObjectInputStream(flujo);

                //Declaramos un objeto de la clase Clientes, y utilizamos "lector" para leerlo del fichero 
                //Recordarmos que almacena los objetos de forma secuencial.
                //Para poder almacenar el objeto leido del fichero, HAY QUE HACER UN CASTING para que entienda y "pueda darle forma a esos bytes" 
                Clientes cliente = (Clientes) lector.readObject();
                System.out.println("LISTADO DE CLIENTES");
                System.out.println("===================");

                //Realmente... podriamos hacer un bucle infinito, ya que el bucle saldrá cuando se produza la EOFException
                //al llegar al final del archivo.
                while (cliente != null) {
                    
                    System.out.println("NIF: " + cliente.getNif());
                    System.out.println("NOMBRE: " + cliente.getNombre());
                    System.out.println("TELEFONO: " + cliente.getTelefono());
                    System.out.println("DIRECCION: " + cliente.getDireccion());
                    System.out.println("DEUDA: " + cliente.getDeuda());
                    System.out.println("");

                    //volvemos a crear a cliente con una nueva lectura
                    cliente = (Clientes) lector.readObject();
                }
                //Cerramos flujo y lector
                flujo.close();
                lector.close();

                //Agregamos la Excepcion EOF que indicará que se llegó al final del archivo    
            } catch (EOFException fnfe) {
                System.out.println("\n+Fin del fichero.\n");
            } catch (FileNotFoundException fnfe) {
                System.out.println("Fichero no encontrado");
            } catch (IOException ioe) {
                System.out.println("Error de fichero");
            } catch (Exception e) {
                System.out.println("Error de fichero");
            }
        }

//=======================================================================================================      
        public static boolean buscarClientes(String buscarNif) {
            boolean encontrado = false;
            try {
                File fichero = new File("cli.dat");
                FileInputStream flujo = new FileInputStream(fichero);
                ObjectInputStream lector = new ObjectInputStream(flujo);
                
                while (!encontrado) {
                    //Para poder almacenar el objeto leido del fichero, HAY QUE HACER UN CASTING para que entienda y "pueda darle forma a esos bytes" 
                    Clientes cliente = (Clientes) lector.readObject();
                    if (buscarNif.equalsIgnoreCase(cliente.getNif())) {
                        
                        System.out.println("DATOS DEL CLIENTE BUSCADO");
                        System.out.println("=========================");
                        System.out.println("NIF: " + cliente.getNif());
                        System.out.println("NOMBRE: " + cliente.getNombre());
                        System.out.println("TELEFONO: " + cliente.getTelefono());
                        System.out.println("DIRECCION: " + cliente.getDireccion());
                        System.out.println("DEUDA: " + cliente.getDeuda());
                        
                        encontrado = true;
                        //  break;
                        //Haremos un poquito de trampas para no hacer un BREAK aquí en medio y lanzaremos un excepcion EOF.
                        throw new EOFException();
                    }
                }
                flujo.close();
                lector.close();

                //Agregamos la Excepcion EOF que indicará que se llegó al final del archivo, Y MOSTRAREMOS QUE LLEGAMOS AL FIN D ESTE      
            } catch (EOFException fnfe) {
                if (!encontrado) {
                    System.out.println("El cliente buscado no existe");
                }//Fin del IF
                
            } catch (FileNotFoundException fnfe) {
                System.out.println("Fichero no encontrado");
            } catch (IOException ioe) {
                System.out.println("Error de fichero");
            } catch (Exception e) {
                System.out.println("Error de fichero");
            }//Fin del Try-Catch

            return encontrado;
        }

//=======================================================================================================      
//Creamos un archivo Auxiliar y luego hay que Buscar el cliente que se quiere borrar en el fichero actual, y simplemente vamos copiando de un archivo, en caso de encontrar al objeto buscado, no lo escribimos en el archivo AUX 
        public static void borrarCliente(String borrarNif) throws IOException, ClassNotFoundException {
            //Inicializamos objetos;
            File ficheRoentrada = null;
            File ficheRosalida = null;
            FileInputStream fluJoentrada = null;
            FileOutputStream fluJosalida = null;
            ObjectInputStream lector = null;
            ObjectOutputStream escritor = null;
            boolean encontrado = false;
            
            try {
                //Abrimos el fichero "existente" y procederemos a leerlo y buscaremos si el DNI introducido está en el archivo
                ficheRoentrada = new File("cli.dat");
                //En caso de que no existe el archivo, lo crearemos
                if (ficheRoentrada.exists() == false) {
                    ficheRoentrada.createNewFile();
                }
                fluJoentrada = new FileInputStream(ficheRoentrada);
                lector = new ObjectInputStream(fluJoentrada);

                //Creamos el archivo AUXILIAR y lo preparamos, para en caso de ENCONTRAR el DNI, copiaremos todos los objetos a este nuevo archivo, menos el que queremos borrar 
                ficheRosalida = new File("cliAUX.dat");
                ficheRosalida.createNewFile();
                fluJosalida = new FileOutputStream(ficheRosalida, true);
                escritor = new ObjectOutputStream(fluJosalida);

                //Para poder almacenar el objeto leido del fichero, HAY QUE HACER UN CASTING para que entienda y "pueda darle forma a esos bytes" 
                Clientes cliente = (Clientes) lector.readObject();

                //En ralidad podriamos dejar este bucle como INFINITO, porque ya saldrá el solocuando llegue al final del archivo
                while (cliente != null) {

                    //Y aquí llega "la magia de los picapiedras.
                    //Solicitamos el DNI, y mientras NO sea el mismo que pasé el usuario los escribimos en el archivo AUX y si COINCIDEN, pues no lo escribimos al archivo AUX
                    if (!borrarNif.equals(cliente.getNif())) {

                        //Volvemos a hacer lo explicado en el metodo crear, dependiendo si tiene o no registros ya, escribiremos los objetos CON las cabeceras o SIN ellas
                        if (ficheRosalida.length() == 0) {
                            escritor = new ObjectOutputStream(fluJosalida);
                            escritor.writeObject(cliente);
                            
                        } else {
                            escritor = new MiObjectOutputStream(fluJosalida);
                            escritor.writeObject(cliente);
                            
                        }
                        
                    } else {
                        encontrado = true;
                    }

                    //volvemos a crear a cliente con una nueva lectura
                    cliente = (Clientes) lector.readObject();
                    
                }//Fin del while

                lector.close();

                //Agregamos la Excepcion EOF que indicará que se llegó al final del archivo, Y MOSTRAREMOS QUE LLEGAMOS AL FIN D ESTE          
            } catch (EOFException fnfe) {
                //   System.out.println("+Fin del fichero.\n");
                //Mostrando mensaje final, indicando si eliminó o no al cliente buscado. 
                if (encontrado) {
                    System.out.println("\nEl Cliente Fue eliminado con Exito.\n\n");
                } else {
                    System.out.println("\nNo se encontró el cliente en la lista.\n\n");
                }//Fin del if-else

            } catch (FileNotFoundException fnfe) {
                System.out.println("Fichero no encontrado");
            } catch (IOException ioe) {
                System.out.println("Error de fichero");
            } catch (Exception e) {
                System.out.println("Error de fichero");
            }//Fin del try-catch

            try {

                //ATENCIÓN//Cuidado con el orden//
                //Seguir este ORDEN es MUY IMPORTANTE, que despues... vienen los problemas, los llantos y las desesperaciones ;D
                ficheRoentrada.delete();//Eliminamos archivo que existía y contiene TODOS los objetos
                //ejecutamos el recolector de basura para que pueda eliminar correctamente el archivo.
                System.gc();
                ficheRosalida.renameTo(ficheRoentrada);//Renombramos archivo AUX que ya no contiene el objeto, al nombre del archivo que existía antes, quedandose este en su lugar
                //Cerramos flujos
                fluJosalida.close();
                fluJoentrada.close();
                //Cerramos lectoy y escritor
                lector.close();
                escritor.close();
                
            } catch (IOException ioe) {
                System.out.println("Error de fichero");
            }//Fin fel try-catch

        }//Fin del método

//=======================================================================================================  
        public static void borrarFichero() {
            //Cargamos el fichero actual
            File fichero = new File("cli.dat");
            //y le mandamos matarile (en caso de que exista)
            if (fichero.exists()) {
                fichero.delete();
                //ejecutamos el recolector de basura para que pueda eliminar correctamente el archivo.
                System.gc();
                
                System.out.println("\n\nEl fichero ha sido borrado.");
            } else {
                System.out.println("\n\nNo se puede borrar, El fichero NO Existe (o_O).\n\n");
            }//Fin del IfElse

        }//Fin del método

//=======================================================================================================  
    }//Fin de la clase principal

//
//
////////////////////////////////////////////////////////////
//ADJUNTANDO CLASE "MiObjectInputStream" con la que FUNCIONA el EJEMPLO
///////////////////////////////////////////////////////////
//
//

    /**
     * Javier Abellán, 20 Marzo 2006 Redefinicion de la clase ObjectOutputStream
     * para que no escriba una cabecera al principio del Stream.
     */

    /**
     * Redefinición de la clase ObjectOuputStream para que no escriba una
     * cabecera al inicio del Stream.
     *
     * @author Javier Abellán.
     *
     */

        
        
        
        
    
    

